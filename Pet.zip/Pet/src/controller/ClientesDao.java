package controller;

import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import model.Cliente;

public class ClientesDao  extends ConectarDao {
  

    public ClientesDao() {
       super();
    }

    public ResultSet buscarTodos() {
          sql = "SELECT * FROM clientes ";
        try {
            ps = mycon.prepareStatement(sql);
            return ps.executeQuery();
        } catch (SQLException err) {
            System.out.println(err.getErrorCode());
        }
        return null;
    }

    public void incluir(Cliente cliente) {
       try {
           
            
            sql = "INSERT INTO clientes ( Dono, CPF, Telefone, Endereco, Email, NomePet, Dados  )"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?)";
            ps = mycon.prepareStatement(sql);
            
            ps.setString(1, cliente.getNome());
            ps.setString(2, cliente.getCPF());
            ps.setString(3, cliente.getTelefone());
            ps.setString(4, cliente.getEndereco());
            ps.setString(5, cliente.getEmail());
            ps.setString(6, cliente.getNomePet());
            ps.setString(7, cliente.getDadosPet());
            
            ps.execute();
            
            JOptionPane.showMessageDialog(null, "Registro de Cliente Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir registro de Cliente: " + err.getMessage());
        }
    
    }

    public ResultSet obterTodosClientesResultSet() {
          sql = "SELECT * FROM clientes";
        try {
            ps = mycon.prepareStatement(sql);
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao obter registros de Cliente!" + err.getMessage());
        }
        return null;
    }
    public ResultSet buscarClientePorcpfResultSet(String cpfCliente) {
    sql = "SELECT * FROM clientes WHERE Cpf = ?";
    try {
        ps = mycon.prepareStatement(sql);
        ps.setString(1, cpfCliente);
        return ps.executeQuery();
    } catch (SQLException err) {
        JOptionPane.showMessageDialog(null, "Erro ao buscar registros de Cliente por cpf!" + err.getMessage());
    }
    return null;
}
}
