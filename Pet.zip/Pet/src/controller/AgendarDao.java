/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.sql.ResultSet;
import Model.AgendarM;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Kelly
 */
public class AgendarDao extends ConectarDao { 
 private PreparedStatement ps;

    
public AgendarDao(){ 
    super(); 
}
     public ResultSet buscarTodos() {
        sql = "SELECT * FROM Agendamento a, clientes c WHERE a.IDdoPet = c.IDdoPet ORDER BY c.nomepet";
        try {
            ps = mycon.prepareStatement(sql);
            return ps.executeQuery();
        } catch (SQLException err) {
            System.out.println(err.getErrorCode());
        }
        return null;
    }

    public void incluir(AgendarM agendar) {
       try {
           
            
            sql = "INSERT INTO Agendamento(IDdoPet, HORARIO, DATA )"
                    + " VALUES (?, ?, ?)";
            ps = mycon.prepareStatement(sql);
            
          
            ps.setString(1, agendar.getIdPet());
            ps.setString(2, agendar.getHorario());
            ps.setString(3, agendar.getData());
          
           
            
            ps.execute();
            
            JOptionPane.showMessageDialog(null, "Registro de agendamento Incluído com Sucesso!");
        } catch (SQLException err) {
            
            JOptionPane.showMessageDialog(null, "Erro ao incluir registro de agendamento: " + err.getMessage());
        }
    
    }
          public ResultSet obterTodosAgendamentosResultSet() {
          sql = "SELECT * FROM Agendamento";
        try {
            ps = mycon.prepareStatement(sql);
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao obter registros de agendamento!" + err.getMessage());
        }
        return null;
    }
    public ResultSet buscarClientePorNomeResultSet(String nomeCliente) {
    sql = "SELECT * FROM Agendamento WHERE IDdoPet = ?";
    try {
        ps = mycon.prepareStatement(sql);
        ps.setString(1, nomeCliente);
        return ps.executeQuery();
    } catch (SQLException err) {
        JOptionPane.showMessageDialog(null, "Erro ao buscar registros de agendamento!" + err.getMessage());
    }
    return null;
}
    
    public ResultSet buscarPet (int IDdoPet) {
        sql = "SELECT * FROM clientes WHERE IDdoPet = ?";
        try {
            ps = mycon.prepareStatement(sql);
            ps.setInt(1, IDdoPet);
            return ps.executeQuery();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar registros de clientes: " + err.getMessage());
        }
        return null;
}
}
