package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class ConectarDao {
    public Connection mycon = null;
    private final String url = "jdbc:mysql://localhost:3306";
    private final String user = "root";
    private final String senha = ""; 
    public PreparedStatement ps = null;
    public String sql = null;
    
    ConectarDao() {
        try {
            mycon = DriverManager.getConnection(url, user, senha);
            System.out.println("Conexão bem sucedida!");
            this.criarBanco();
            
        } catch (SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
         
        }
    }

      
    
    public void criarBanco () {
        
         

        try {
            
            ps = mycon.prepareStatement("create database if not exists PetMiau");
            ps.execute();
            
            ps = mycon.prepareStatement("use PetMiau");
            ps.execute();
            
          sql= "create table  if not exists clientes(  "
                    + "IDdoPet INT AUTO_INCREMENT PRIMARY KEY,"
                    + "Telefone varchar(20),"
                    + "CPF VARCHAR(20),"
                    + "Dono VARCHAR(100),"
                    + "Endereco VARCHAR(100),"
                    + "Email VARCHAR(100) ,"
                  + "NomePet varchar(30) not null,"
                  + "Dados varchar(200)); ";
            ps = mycon.prepareStatement(sql);
            ps.execute();
            
            
           
            
             sql= "create table  if not exists Agendamento(  "
                    + "IDdoAgendamento INT AUTO_INCREMENT PRIMARY KEY,"
                    + "IDdoPet INT not null,"              
                    + " Horario VARCHAR(10),"
                     + "Data VARCHAR(11))";
                    
            ps = mycon.prepareStatement(sql);
            ps.execute();
            
            
             
 
} catch (SQLException err) {
JOptionPane.showMessageDialog(null, "Erro ao criar banco de dados " + err.getMessage() + "\n" + err.getErrorCode() );
        }
    
    }
 
}