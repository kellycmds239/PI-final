
package Model;

import java.util.Date;

public class AgendarM {


private String data;
private String horario;
private String idPet;



public String getData(){
        return data;
    }
    
    public void setData(String data){
        this.data=data;
    }
    
    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    

    public String getIdPet() {
        return idPet;
    }

    public void setIdPet(String idp) {
        this.idPet = idp;
    }

    public void getidPet(String text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
}
